package edu.ilstu;

public interface Payable {
	
	public double calculatePay();

}
