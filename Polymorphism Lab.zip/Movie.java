package edu.ilstu;

public interface Movie {
	
	void printDirector();

}
