package edu.ilstu;

public interface Multimedia {

	void printDuration();
	
	
}
